package io.flutter.ninja.jobfinder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
